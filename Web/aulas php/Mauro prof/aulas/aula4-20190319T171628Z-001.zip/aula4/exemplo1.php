<!-- http://localhost/site/exemplo1.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tamanho de string</title>
</head>
<body>
<?php
    $tamanho = strlen("fulano");  
    echo "Tamanho da str: $tamanho";
?>
</body>
</html>